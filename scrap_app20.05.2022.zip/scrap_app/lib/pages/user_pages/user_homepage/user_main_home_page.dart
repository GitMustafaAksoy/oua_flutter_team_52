import 'dart:convert';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:scrap_app/pages/user_pages/user_homepage/call_scrap_dealer_button/call_scrap_dealer_button.dart';

import 'theme/colors/light_colors.dart';
import 'user_home_page_widget/box_card.dart';

class UserHomePage extends StatelessWidget {
  const UserHomePage({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'User Home Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: Theme.of(context).textTheme.apply(
            bodyColor: LightColors.kDarkBlue,
            displayColor: LightColors.kDarkBlue,
            fontFamily: 'Poppins'),
      ),
      home: const UserScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class UserScreen extends StatefulWidget {
  const UserScreen({Key? key}) : super(key: key);

  @override
  State<UserScreen> createState() => _UserScreenState();
}

class _UserScreenState extends State<UserScreen> {
  Text subheading(String title) {
    return Text(
      title,
      style: const TextStyle(
          color: LightColors.kDarkBlue,
          fontSize: 20.0,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.4),
    );
  }
  String boxID ='';
  String? boxesData;
  Map<String, dynamic>? boxesConvertedData;
  List? boxesValuesList;
  List? boxesKeysList;



  void addBoxID(String text) {
    setState(() {
      boxID = text;
      print(boxID);
      DatabaseReference boxesTaskRef =
      FirebaseDatabase.instance.ref('/allboxes/box$boxID/Boxes/');
      boxesTaskRef.onValue.listen((event) {
        setState(() {
          boxesData = jsonEncode(event.snapshot.value);
          boxesConvertedData = jsonDecode(boxesData!);
          boxesValuesList = boxesConvertedData!.values.toList();
          boxesKeysList = boxesConvertedData!.keys.toList();
        });
      });
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LightColors.kLightWhite,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Container(
              padding: const EdgeInsets.all(8.0),
              child: subheading('Apartment Boxes'),
            ),
            Expanded(
              child: boxesValuesList != null && boxesKeysList != null
                  ? GridView.builder(
                      itemCount: boxesValuesList!.length,
                      itemBuilder: (context, index) => BoxRow(
                        boxesKeysList![index],
                        boxesValuesList![index],
                      ),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        mainAxisExtent: 220,
                        crossAxisCount: 2,
                      ),
                    )
                  : const Center(child: CircularProgressIndicator()),
            ),
            AddBox(addBoxID: addBoxID),
            const CallScrapDealer(),
            Text(boxID),
          ],
        ),
      ),
    );
  }
}

class AddBox extends StatefulWidget {
  final void Function(String text) addBoxID;

  const AddBox({
    Key? key,
    required this.addBoxID,
  }) : super(key: key);

  @override
  State<AddBox> createState() => _AddBoxState();
}

class _AddBoxState extends State<AddBox> {
  void runToUserAddBoxPage() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => UserAddBoxPage(addBoxID: widget.addBoxID,),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        runToUserAddBoxPage();
      },
      child: Container(
        margin: const EdgeInsets.only(left: 20, right: 20, bottom: 10, top: 10),
        height: 50,
        decoration: BoxDecoration(
          color: LightColors.Paper,
          borderRadius: BorderRadius.circular(15.0),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  'Add Your Apartment Boxes Id',
                  style: TextStyle(
                    fontSize: 14.0,
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class UserAddBoxPage extends StatefulWidget {

  void Function(String text) addBoxID;

  UserAddBoxPage({
    Key? key,
    required this.addBoxID,
  }) : super(key: key);

  @override
  State<UserAddBoxPage> createState() => _UserAddBoxPageState();
}

class _UserAddBoxPageState extends State<UserAddBoxPage> {
  final controller = TextEditingController();

  Text subheading(String title) {
    return Text(
      title,
      style: const TextStyle(
          color: LightColors.kDarkBlue,
          fontSize: 20.0,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.4),
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            PhysicalModel(
              color: Colors.white,
              elevation: 10,
              child: Padding(
                padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                child: Center(child: subheading('Add Your Box Id')),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                  child: TextField(
                    controller: controller,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      hintText: 'Enter your box id',
                    ),
                  ),
                ),
                ElevatedButton(
                    onPressed: () {
                        widget.addBoxID(controller.text);
                        controller.text = '';
                    },
                    child: Text('Ekle')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class BoxRow extends StatelessWidget {
  String keyIndex;
  String valueIndex;

  BoxRow(
    this.keyIndex,
    this.valueIndex, {
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(left: 10, right: 10, bottom: 0, top: 0),
      color: Colors.transparent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          GestureDetector(
            onTap: () {
              print('ABC');
              print('ABCS');
            },
            child: Row(
              children: <Widget>[
                BoxCard(
                  boxColor: keyIndex == 'Glass Box'
                      ? LightColors.kGreen
                      : keyIndex == 'Plastic Box'
                          ? LightColors.kRed
                          : keyIndex == 'Electronic  Box'
                              ? LightColors.kBlue
                              : keyIndex == 'Metal Box'
                                  ? LightColors.kDarkBlue
                                  : keyIndex == 'Oil Box'
                                      ? LightColors.kDarkYellow
                                      : keyIndex == 'Paper Box'
                                          ? LightColors.Paper
                                          : LightColors.Paper,
                  loadingPercent: int.parse(valueIndex) / 100,
                  boxTitle: keyIndex,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
