import 'package:flutter/material.dart';

import 'call_scrap_dealer_page.dart';
import 'user_add_box_page.dart';

class UserHomePa extends StatefulWidget {
  const UserHomePa({Key? key}) : super(key: key);

  @override
  State<UserHomePa> createState() => _UserHomePaState();
}

class _UserHomePaState extends State<UserHomePa> {
  void runToUserAddBoxPage() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => UserAddBoxPage(),
    ));
  }

  void runToCallScrapDealerPage() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => CallScrapDealerPage(),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('UserHomePage'),
            Text('Kutu ekranı'),
            Padding(
              padding: const EdgeInsets.all(8),
              child: true == false
                  ? ElevatedButton(
                      onPressed: () {
                        runToUserAddBoxPage();
                      },
                      child: Text('Kutu Ekle'),
                    )
                  : Placeholder(fallbackWidth: 400, fallbackHeight: 400),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    runToCallScrapDealerPage();
                  });
                },
                child: Text('Call a scrap dealer'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
