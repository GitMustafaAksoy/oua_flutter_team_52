import 'dart:convert';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';

import 'theme/colors/light_colors.dart';
import 'user_home_page_widget/box_card.dart';

class UserHomePage extends StatelessWidget {
  const UserHomePage({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'User Home Page',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: Theme.of(context).textTheme.apply(
            bodyColor: LightColors.kDarkBlue,
            displayColor: LightColors.kDarkBlue,
            fontFamily: 'Poppins'),
      ),
      home: const UserScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class UserScreen extends StatefulWidget {
  const UserScreen({Key? key}) : super(key: key);

  @override
  State<UserScreen> createState() => _UserScreenState();
}

class _UserScreenState extends State<UserScreen> {
  Text subheading(String title) {
    return Text(
      title,
      style: const TextStyle(
          color: LightColors.kDarkBlue,
          fontSize: 20.0,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.4),
    );
  }

  DatabaseReference taskRef = FirebaseDatabase.instance.ref('box00001');
  String? data;
  Map<String, dynamic>? convertedData;
  List? valuesList;
  List? keysList;
  List? firstKeysList;
  List? secondKeysList;
  List? firstValuesList;
  List? secondValuesList;

  @override
  void initState() {
    taskRef.onValue.listen((event) {
      setState(() {
        data = jsonEncode(event.snapshot.value);
        convertedData = jsonDecode(data!);
        valuesList = convertedData!.values.toList();
        keysList = convertedData!.keys.toList();
        firstKeysList = keysList!.getRange(0, 3).toList();
        secondKeysList = keysList!.getRange(3, 6).toList();
        firstValuesList = valuesList!.getRange(0, 3).toList();
        secondValuesList = valuesList!.getRange(3, 6).toList();
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LightColors.kLightWhite,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Container(
              padding: EdgeInsets.all(8.0),
              child: subheading('Apartment Boxes'),
            ),
            Expanded(
              child: valuesList != null && keysList != null
                  ? ListView.builder(
                      itemCount: (valuesList!.length / 2).round(),
                      itemBuilder: (context, index) => BoxRow(
                            firstKeysList![index],
                            secondKeysList![index],
                            firstValuesList![index],
                            secondValuesList![index],
                          ))
                  : const Center(child: CircularProgressIndicator()),
            ),
          ],
        ),
      ),
    );
  }
}

class BoxRow extends StatefulWidget {
  String keyIndexFromFirstList;
  String keyIndexFromSecondList;
  String valueIndexFromFirstList;
  String valueIndexFromSecondList;

  BoxRow(
    this.keyIndexFromFirstList,
    this.keyIndexFromSecondList,
    this.valueIndexFromFirstList,
    this.valueIndexFromSecondList, {
    Key? key,
  }) : super(key: key);

  @override
  State<BoxRow> createState() => _BoxRowState();
}

class _BoxRowState extends State<BoxRow> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.transparent,
      padding: const EdgeInsets.symmetric(horizontal: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          GestureDetector(
            onTap: () {
              print('ABC');
              print('ABCS');
            },
            child: Row(
              children: <Widget>[
                BoxCard(
                  cardColor: widget.keyIndexFromFirstList == 'Glass Box'
                      ? LightColors.kGreen
                      : widget.keyIndexFromFirstList == 'Plastic Box'
                          ? LightColors.kRed
                          : widget.keyIndexFromFirstList == 'Electronic  Box'
                              ? LightColors.kBlue
                              : LightColors.kBlue,
                  loadingPercent:
                      int.parse(widget.valueIndexFromFirstList) / 100,
                  title: widget.keyIndexFromFirstList,
                ),
                const SizedBox(width: 20.0),
                BoxCard(
                  cardColor: widget.keyIndexFromSecondList == 'Metal Box'
                      ? LightColors.kDarkBlue
                      : widget.keyIndexFromSecondList == 'Oil Box'
                          ? LightColors.kDarkYellow
                          : widget.keyIndexFromSecondList == 'Paper  Box'
                              ? LightColors.Paper
                              : LightColors.Paper,
                  loadingPercent:
                      int.parse(widget.valueIndexFromSecondList) / 100,
                  title: widget.keyIndexFromSecondList,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
