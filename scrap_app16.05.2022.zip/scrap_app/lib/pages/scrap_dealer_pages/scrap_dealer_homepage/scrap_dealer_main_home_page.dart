import 'package:flutter/material.dart';

import 'theme/colors/light_colors.dart';
import 'widgets/box_types.dart';
import 'widgets/open_to_offer_boxes.dart';

class ScrapDealerHomePage extends StatelessWidget {
  const ScrapDealerHomePage({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: Theme.of(context).textTheme.apply(
            bodyColor: LightColors.kDarkBlue,
            displayColor: LightColors.kDarkBlue,
            fontFamily: 'Poppins'),
      ),
      home: ScrapDealerScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ScrapDealerScreen extends StatelessWidget {
  Text subheading(String title) {
    return Text(
      title,
      style: TextStyle(
          color: LightColors.kDarkBlue,
          fontSize: 20.0,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LightColors.kLightWhite,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: <Widget>[
                    Container(
                      color: Colors.transparent,
                      padding: EdgeInsets.symmetric(
                          horizontal: 20.0, vertical: 10.0),
                      child: Column(
                        children: <Widget>[
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              subheading('Atık Türleri'),
                            ],
                          ),
                          Container(
                            margin: const EdgeInsets.symmetric(vertical: 10.0),
                            height: 50,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: BoxTypes(
                                    icon: Icons.recycling,
                                    iconBackgroundColor: LightColors.kGreen,
                                    title: 'Glass',
                                    subtitle: '2 glass boxes',
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: BoxTypes(
                                    icon: Icons.recycling,
                                    iconBackgroundColor: LightColors.kRed,
                                    title: 'Plastic',
                                    subtitle: '18 plastic boxes',
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: BoxTypes(
                                    icon: Icons.recycling,
                                    iconBackgroundColor: LightColors.kBlue,
                                    title: 'Electronic',
                                    subtitle: '2 electronic boxes',
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: BoxTypes(
                                    icon: Icons.recycling,
                                    iconBackgroundColor: LightColors.kDarkBlue,
                                    title: 'Metal',
                                    subtitle: '2 metal boxes',
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: BoxTypes(
                                    icon: Icons.recycling,
                                    iconBackgroundColor: LightColors.kDarkYellow,
                                    title: 'Oil',
                                    subtitle: '2 oil boxes',
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0),
                                  child: BoxTypes(
                                    icon: Icons.recycling,
                                    iconBackgroundColor: LightColors.Paper,
                                    title: 'Paper',
                                    subtitle: '2 paper boxes',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      color: Colors.transparent,
                      padding: EdgeInsets.symmetric(
                          horizontal: 20.0, vertical: 10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          subheading('Teklife Açık Kutular'),
                          SizedBox(height: 5.0),
                          Row(
                            children: <Widget>[
                              OpenedBoxesForOffer(
                                cardColor: LightColors.kGreen,
                                loadingPercent: 0.25,
                                title: 'Paper Box',
                                subtitle: 'Keçiören',
                              ),
                              SizedBox(width: 20.0),
                              OpenedBoxesForOffer(
                                cardColor: LightColors.kRed,
                                loadingPercent: 0.6,
                                title: 'Elektronic Box',
                                subtitle: 'Çankaya',
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
