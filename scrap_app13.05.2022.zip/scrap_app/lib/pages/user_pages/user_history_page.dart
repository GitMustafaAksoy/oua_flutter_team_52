import 'package:flutter/material.dart';

class UserSalesHistoryPage extends StatefulWidget {
  const UserSalesHistoryPage({
    Key? key,
  }) : super(key: key);

  @override
  State<UserSalesHistoryPage> createState() => _UserSalesHistoryPageState();
}

class _UserSalesHistoryPageState extends State<UserSalesHistoryPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          PhysicalModel(
            color: Colors.white,
            elevation: 10,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 32),
              child: Center(child: Text('UserHistoryPage')),
            ),
          ),
          Expanded(
              child: ListView.separated(
                itemBuilder: (context, index) => PlanRow(),
                separatorBuilder: (context, index) => const Divider(),
                itemCount: 3,
              )),
        ],
      ),
    );
  }
}

class PlanRow extends StatefulWidget {
  const PlanRow({
    Key? key,
  }) : super(key: key);

  @override
  State<PlanRow> createState() => _PlanRowState();
}

class _PlanRowState extends State<PlanRow> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text('Satılanlar Satırı'),
      trailing: IconButton(
        onPressed: () {
          setState(() {});
        },
        icon: Icon(Icons.delete),
      ),
    );
  }
}
