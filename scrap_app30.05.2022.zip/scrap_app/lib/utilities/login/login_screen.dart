import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:scrap_app/pages/admin_pages/admin_nav_bar_page.dart';
import 'package:scrap_app/pages/scrap_dealer_pages/scrap_dealer_nav_bar_page.dart';
import 'package:scrap_app/pages/user_pages/user_nav_bar_page.dart';
import 'package:scrap_app/utilities/login/con_without_login_page.dart';
import 'package:scrap_app/utilities/login/google_sign_in_page.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool isFirebaseInitialized = false;

  @override
  void initState() {
    // TODO: implement initState
    initializeFirebase();
    super.initState();
  }

  Future<void> initializeFirebase() async {
    await Firebase.initializeApp();
    setState(() {
      isFirebaseInitialized = true;
    });
    await isUserLoggedIn();
  }

  //This meth. checks users if they are already logged in and redirect them to their homepages.
  Future<void> isUserLoggedIn() async {
    if (FirebaseAuth.instance.currentUser != null) {
      String uid = FirebaseAuth.instance.currentUser!.uid;
      DocumentSnapshot<Map<String, dynamic>> userData =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (userData['role'] == 'user') {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => UserNavBar()));
      } else if (userData['role'] == 'admin') {
        Navigator.of(context)
            .pushReplacement(MaterialPageRoute(builder: (context) {
          return AdminNavBar();
        }));
      } else if (userData['role'] == 'scrap dealer') {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => ScrapDealerNavBar()));
      }
    }
  }

  // void runToUserHomePage() {
  //   Navigator.of(context).pushReplacement(MaterialPageRoute(
  //     builder: (context) => UserNavBar(),
  //   ));
  // }

  void continueWithoutLogin() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (context) => ContinueWithoutLoginPage(),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: isFirebaseInitialized
                ? SignInButton(
                    Buttons.Google,
                    onPressed: () async {
                      await signInWithGoogle();
                      String? name =
                          FirebaseAuth.instance.currentUser!.displayName;
                      String? email = FirebaseAuth.instance.currentUser!.email;
                      String uid = FirebaseAuth.instance.currentUser!.uid;
                      DocumentSnapshot<Map<String, dynamic>> toCheckUserData =
                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(uid)
                          .get();
                      DocumentSnapshot<Map<String, dynamic>> toCheckUserExists =
                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(uid)
                          .get();
                      await FirebaseFirestore.instance
                          .collection('users')
                          .doc(uid)
                          .set({
                        'name': name,
                        'email': email,
                        'uid': uid,
                        if (toCheckUserExists.exists == false)
                          'role': 'user',
                        'isUserSignIn': true,
                        'lastLoginTime': FieldValue.serverTimestamp(),
                        if (toCheckUserExists.exists == true &&
                            toCheckUserData['role'] == 'admin')
                          'role': 'admin',
                        'isAdminSignIn': true,
                        'lastLoginTime': FieldValue.serverTimestamp(),
                        if (toCheckUserExists.exists == true &&
                            toCheckUserData['role'] == 'scrap dealer')
                          'role': 'scrap dealer',
                        'isAdminSignIn': true,
                        'lastLoginTime': FieldValue.serverTimestamp(),
                      }, SetOptions(merge: true));
                      isUserLoggedIn();
                    },
                  )
                : const CircularProgressIndicator(),
          ),
          ElevatedButton(
              onPressed: () {
                continueWithoutLogin();
              },
              child: Text('Continue Without Login')),
        ],
      ),
    );
  }
}
