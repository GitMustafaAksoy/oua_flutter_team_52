import 'package:flutter/material.dart';

class AnnouncementToBid extends StatelessWidget {
  final Color boxColor;
  final double loadingPercent;
  final String boxTitle;
  final String boxProvince;

  AnnouncementToBid({
    required this.boxColor,
    required this.loadingPercent,
    required this.boxTitle,
    required this.boxProvince,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10.0),
      padding: const EdgeInsets.all(20.0),
      height: 250,
      decoration: BoxDecoration(
        color: boxColor,
        borderRadius: BorderRadius.circular(15.0),
      ),
      child: Column(
        children: <Widget>[
            Text(
                  '15 KG',
                  style: TextStyle(
                      fontWeight: FontWeight.w900, color: Colors.white),
                ),
          Column(
            children: <Widget>[
              Text(
                boxTitle,
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                boxProvince,
                style: TextStyle(
                  fontSize: 12.0,
                  color: Colors.white54,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
