import 'dart:convert';

import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:scrap_app/pages/scrap_dealer_pages/scrap_dealer_homepage/theme/colors/light_colors.dart';
import 'package:scrap_app/pages/scrap_dealer_pages/scrap_dealer_homepage/widgets/box_types.dart';
import 'package:scrap_app/pages/scrap_dealer_pages/scrap_dealer_homepage/widgets/open_to_offer_boxes.dart';

class ScrapDealerHomePage extends StatelessWidget {
  const ScrapDealerHomePage({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
        textTheme: Theme.of(context).textTheme.apply(
            bodyColor: LightColors.kDarkBlue,
            displayColor: LightColors.kDarkBlue,
            fontFamily: 'Poppins'),
      ),
      home: ScrapDealerScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ScrapDealerScreen extends StatefulWidget {
  @override
  State<ScrapDealerScreen> createState() => _ScrapDealerScreenState();
}

class _ScrapDealerScreenState extends State<ScrapDealerScreen> {
  Text subheading(String title) {
    return Text(
      title,
      style: TextStyle(
          color: LightColors.kDarkBlue,
          fontSize: 20.0,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2),
    );
  }

  DatabaseReference boxesTaskRef =
      FirebaseDatabase.instance.ref('/allboxes/box00002/Boxes/');

  String? boxesData;
  Map<String, dynamic>? boxesConvertedData;
  List? boxesValuesList;
  List? boxesKeysList;

  DatabaseReference infoTaskRef =
      FirebaseDatabase.instance.ref('/allboxes/box00002/Info/');

  String? infoData;
  Map<String, dynamic>? infoConvertedData;
  List? infoValuesList;

  @override
  void initState() {
    boxesTaskRef.onValue.listen((event) {
      setState(() {
        boxesData = jsonEncode(event.snapshot.value);
        boxesConvertedData = jsonDecode(boxesData!);
        boxesValuesList = boxesConvertedData!.values.toList();
        boxesKeysList = boxesConvertedData!.keys.toList();
      });
    });
    infoTaskRef.onValue.listen((event) {
      setState(() {
        infoData = jsonEncode(event.snapshot.value);
        infoConvertedData = jsonDecode(infoData!);
        infoValuesList = infoConvertedData!.values.toList();
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LightColors.kLightWhite,
      body: SafeArea(
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  subheading('Atık Türleri'),
                ],
              ),
              TypesOfBoxes(),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2.5),
                child: Row(
                  children: [
                    subheading('Teklife Açık Kutular'),
                    SizedBox(height: 20),
                  ],
                ),
              ),
              Expanded(
                child: boxesValuesList != null && boxesKeysList != null && infoValuesList != null
                    ? GridView.builder(
                        shrinkWrap: true,
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          mainAxisExtent: 220,
                          crossAxisCount: 2,
                          crossAxisSpacing: 15,
                        ),
                        itemCount: boxesValuesList!.length,
                        itemBuilder: (context, index) => OpenedBoxesGrid(
                          boxesValuesList![index],
                          boxesKeysList![index],
                          infoValuesList!,
                        ),
                      )
                    : Center(child: const CircularProgressIndicator()),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class OpenedBoxesGrid extends StatelessWidget {
  String valueIndex;
  String keyIndex;
  List<dynamic> infoValuesList;

  OpenedBoxesGrid(
    this.valueIndex,
    this.keyIndex,
    this.infoValuesList, {
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return OpenedBoxesForOffer(
      boxColor: keyIndex == 'Glass Box'
          ? LightColors.kGreen
          : keyIndex == 'Plastic Box'
              ? LightColors.kRed
              : keyIndex == 'Electronic  Box'
                  ? LightColors.kBlue
                  : keyIndex == 'Metal Box'
                      ? LightColors.kDarkBlue
                      : keyIndex == 'Oil Box'
                          ? LightColors.kDarkYellow
                          : keyIndex == 'Paper Box'
                              ? LightColors.Paper
                              : LightColors.Paper,
      loadingPercent: int.parse(valueIndex) / 100,
      boxTitle: keyIndex,
      boxProvince: infoValuesList[1],
    );
  }
}

class TypesOfBoxes extends StatelessWidget {
  TypesOfBoxes({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0),
      height: 50,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: 8.0),
            child: BoxTypes(
              icon: Icons.recycling,
              iconBackgroundColor: LightColors.kGreen,
              title: 'Glass',
              subtitle: '2 glass boxes',
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 8.0),
            child: BoxTypes(
              icon: Icons.recycling,
              iconBackgroundColor: LightColors.kRed,
              title: 'Plastic',
              subtitle: '18 plastic boxes',
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 8.0),
            child: BoxTypes(
              icon: Icons.recycling,
              iconBackgroundColor: LightColors.kBlue,
              title: 'Electronic',
              subtitle: '2 electronic boxes',
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 8.0),
            child: BoxTypes(
              icon: Icons.recycling,
              iconBackgroundColor: LightColors.kDarkBlue,
              title: 'Metal',
              subtitle: '2 metal boxes',
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 8.0),
            child: BoxTypes(
              icon: Icons.recycling,
              iconBackgroundColor: LightColors.kDarkYellow,
              title: 'Oil',
              subtitle: '2 oil boxes',
            ),
          ),
          Padding(
            padding: EdgeInsets.only(right: 8.0),
            child: BoxTypes(
              icon: Icons.recycling,
              iconBackgroundColor: LightColors.Paper,
              title: 'Paper',
              subtitle: '2 paper boxes',
            ),
          ),
        ],
      ),
    );
  }
}
